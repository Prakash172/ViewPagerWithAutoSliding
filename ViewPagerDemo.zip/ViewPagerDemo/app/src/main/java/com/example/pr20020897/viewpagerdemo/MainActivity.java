package com.example.pr20020897.viewpagerdemo;

import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private Handler mHandler;
    public static final int DELAY = 5000;
    private ViewPager viewPager;
    private ViewPagerAdapter adapter;
    private TabLayout indicator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        indicator= findViewById(R.id.indicator);
        viewPager = findViewById(R.id.view_pager);
        adapter = new ViewPagerAdapter(this);
        viewPager.setAdapter(adapter);
        indicator.setupWithViewPager(viewPager);
        mHandler = new Handler();
        mHandler.postDelayed(mRunnable,DELAY);
    }

    Runnable mRunnable = new Runnable()
    {
        @Override
        public void run()
        {
            viewPager.setCurrentItem((viewPager.getCurrentItem()+1)%3);
            mHandler.postDelayed( mRunnable , DELAY );
        }
    };


    @Override
    protected void onDestroy() {
        super.onDestroy();
        mHandler.removeCallbacks(mRunnable);
    }
}
